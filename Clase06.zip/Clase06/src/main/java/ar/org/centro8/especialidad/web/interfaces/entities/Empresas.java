package ar.org.centro8.especialidad.web.interfaces.entities;

import ar.org.centro8.especialidad.web.interfaces.enums.Respuesta;
import ar.org.centro8.especialidad.web.interfaces.enums.TipoDocumento;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name="empresas")
public class Empresas {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private Integer id;
    private String nombre_empresa;
    @Enumerated(value = EnumType.STRING)
    private String numero_cuit;
    @Enumerated(value = EnumType.STRING)
    private String direccion;
    private String telefono;
    private String email;

    public Empresas() {
    }
    
    public Empresas(Integer id, String nombre_empresa, String numero_cuit, String direccion, String telefono,
            String email) {
        this.id = id;
        this.nombre_empresa = nombre_empresa;
        this.numero_cuit = numero_cuit;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
    }
    
    @Override
    public String toString() {
        return "Empresas [id=" + id + ", nombre_empresa=" + nombre_empresa + ", numero_cuit=" + numero_cuit
                + ", direccion=" + direccion + ", telefono=" + telefono + ", email=" + email + "]";
    }

    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getNombre_empresa() {
        return nombre_empresa;
    }
    public void setNombre_empresa(String nombre_empresa) {
        this.nombre_empresa = nombre_empresa;
    }
    public String getNumero_cuit() {
        return numero_cuit;
    }
    public void setNumero_cuit(String numero_cuit) {
        this.numero_cuit = numero_cuit;
    }
    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    
}
