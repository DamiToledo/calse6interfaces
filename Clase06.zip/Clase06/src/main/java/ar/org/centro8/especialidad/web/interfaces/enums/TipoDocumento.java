package ar.org.centro8.especialidad.web.interfaces.enums;

public enum TipoDocumento {
    DNI,
    PASS
}
