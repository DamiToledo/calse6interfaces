package ar.org.centro8.especialidad.web.interfaces.repositories;

import org.springframework.stereotype.Repository;
import ar.org.centro8.especialidad.web.interfaces.entities.Empresas;
import org.springframework.data.repository.CrudRepository;

@Repository
public interface EmpresasRepository extends CrudRepository<Empresas, Integer> {
    
}